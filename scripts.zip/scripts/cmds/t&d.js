const axios = require("axios");
const fs = require("fs");
const path = require("path");

const TOD_JSON_PATH = path.join(__dirname, "tod.json");

// তোমার ৩০টি বাংলা Truth প্রশ্ন এখানে বসাও
const banglaTruths = [
  "তোমার জীবনের সবচেয়ে বড় ভয় কী?",
  "তুমি কখনো কারো প্রতি মিথ্যা বলেছো কি?",
  "তুমি কি কখনো প্রেমে পড়েছো?",
  "তোমার সবচেয়ে লজ্জাজনক মুহূর্ত কী?",
  "তুমি কি গোপনে কাউকে পছন্দ করো?",
  "সবাই তোমার মধ্যে কোন অভ্যাস সবচেয়ে বেশি অপছন্দ করে?",
  "তুমি জীবনে সবচেয়ে বড় কোন ভুল করেছো?",
  "তোমার জীবনের সবচেয়ে অদ্ভুত ঘটনা কী?",
  "তুমি কি কখনো কারো প্রতি ঈর্ষা করেছো?",
  "তোমার সবচেয়ে প্রিয় স্মৃতি কী?",
  "তুমি কি কখনো কাউকে মিথ্যা ভালোবাসার অভিনয় করেছো?",
  "তুমি কি কখনো কাউকে মাফ করেছো, যদিও সে তা প্রাপ্য ছিল না?",
  "তোমার জীবনের সবচেয়ে বড় অর্জন কী?",
  "তুমি সবচেয়ে বেশি কিসের জন্য ধন্যবাদ অনুভব করো?",
  "তুমি কোন কাজ করতে সবচেয়ে বেশি লজ্জা পেয়েছো?",
  "তুমি কি কখনো কাউকে নিয়ে গোপনে কথা বলেছো?",
  "তুমি সবচেয়ে বেশি কোন খাবার পছন্দ করো?",
  "তুমি কি কখনো কাউকে ঠকিয়েছো?",
  "তোমার জীবনে সবচেয়ে বড় লুকানো গোপন কী?",
  "তুমি কি কখনো কাউকে হারিয়ে নিজেকে দোষী মনে করেছো?",
  "তুমি সবচেয়ে ভালো বন্ধু কাউকে ভাবো কেন?",
  "তুমি কোন কারণে কখনো রাগ করেছো, যার জন্য তুমি পরে আফসোস করেছো?",
  "তুমি কি কখনো কোনো সিক্রেট লুকিয়েছো?",
  "তুমি সবচেয়ে বেশি কোন গানে কান্না করেছো?",
  "তুমি কি কখনো কাউকে সাহায্য করার জন্য নিজের কিছু ত্যাগ করেছো?",
  "তুমি কি কখনো গোপনে কাউকে ভালোবাসার কথা অন্য কাউকে বলেছো?",
  "তোমার জীবনের সবচেয়ে বড় শিক্ষা কী?",
  "তুমি কি কখনো কাউকে ভুল বোঝাবুঝি করেছো?",
  "তুমি কোন মুহূর্তে সবচেয়ে সুখী ছিলে?",
  "তুমি কি কখনো কাউকে বোকা বানানোর চেষ্টা করেছো?"
];

// তোমার ৩০টি বাংলা Dare প্রশ্ন এখানে বসাও
const banglaDares = [
  "একজন বন্ধুর কাছে ফোন দিয়ে ‘আমি তোমাকে ভালোবাসি’ বলো।",
  "তিনবার লাফাও এক জায়গায়।",
  "তোমার টেবিলের উপর থেকে একটা অদ্ভুত জিনিস নিয়ে এসো।",
  "তুমি পরবর্তী ৫ মিনিট সিংহের মত ঘুরো।",
  "কেউকে একটা কমপ্লিমেন্ট করো, যাকে আগে কখনো করো নি।",
  "তোমার পরবর্তী মেসেজে শুধুমাত্র ইংরেজি ব্যবহার করো ১০ মিনিটের জন্য।",
  "নিজেকে আয়নায় ৩০ সেকেন্ডের জন্য দেখাও এবং হাসো।",
  "তোমার পকেট থেকে একটা অদ্ভুত জিনিস বের করে সবাইকে দেখাও।",
  "তোমার কাছে সবচেয়ে লজ্জাজনক ছবি শেয়ার করো।",
  "তিনজনকে তোমার সবচেয়ে পছন্দের গানের লাইন বলো।",
  "তুমি তোমার ফ্রেন্ডলিস্ট থেকে এক জনকে স্পেশাল কিছু বলো।",
  "৫ মিনিটের জন্য বন্ধ চোখে ঘোরো।",
  "তুমি তোমার মোবাইল থেকে সবচেয়ে পুরনো ছবি শেয়ার করো।",
  "একজনকে ৩০ সেকেন্ডের জন্য একহাত দিয়ে হেল্লো বলো।",
  "নিজের সবচেয়ে অদ্ভুত অভ্যাস সবাইকে বলো।",
  "তুমি তোমার সামনের ব্যক্তির জন্য একটি কবিতা গাও।",
  "তিনজনকে তোমার সবচেয়ে বড় গোপন কথা বলো।",
  "তুমি তোমার পছন্দের মুভির একটা ডায়লগ বলো।",
  "৫ সেকেন্ডের জন্য সিংহের মত রোলো।",
  "তুমি তোমার ব্যাগ থেকে একটা জিনিস বের করে সবাইকে দেখাও।",
  "যে সবচেয়ে কাছে আছে তাকে একটা মজার মিম শেয়ার করো।",
  "সামনে থাকা লোকেদের জন্য একটা হাস্যকর গল্প বলো।",
  "তুমি তোমার সব সময়ের সবচেয়ে বাজে অভিজ্ঞতা শেয়ার করো।",
  "যে তোমার কাছে সবচেয়ে ঘনিষ্ঠ, তাকে তুমি ভালোবাসো বলো।",
  "তুমি তোমার পরবর্তী মেসেজে শুধুমাত্র গান গাইতে পারবে।",
  "তুমি ৩০ সেকেন্ডের জন্য তোমার পায়ে লাফ দাও।",
  "তুমি তোমার মোবাইল থেকে একটি মজার ভিডিও শেয়ার করো।",
  "যে তোমার পাশে আছে তাকে একটি মজার গল্প বলো।",
  "তুমি তোমার প্রিয় খাবারের নাম সবাইকে বলো।",
  "তুমি নিজের মোবাইল থেকে একটি মজার ছবি শেয়ার করো।"
];

module.exports = {
  config: {
    name: "tod",
    version: "1.2",
    author: "xnil",
    role: 0,
    shortDescription: "Truth and Dare game",
    longDescription: "Play Truth and Dare game in multiple languages including Bangla",
    category: "game",
    guide: {
      en: "{p}tod [truth/dare] [lang/reset]",
    },
  },

  langs: {
    en: {
      askReply: "🔁 What's your answer?",
      replySaved: "✅ Thanks! Your reply has been noted.",
      langSet: "✅ Language set to",
      langNotFound: "❌ Language not available.",
      langReset: "🔄 Language reset to default",
      invalidCmd: "❌ Invalid command!",
      usage: "✅ Usage:\n- tod truth\n- tod dare\n- tod lang bn",
      errorTruth: "❌ Failed to fetch truth question.",
      errorDare: "❌ Failed to fetch dare question."
    },
    bn: {
      askReply: "🔁 তোমার উত্তর কী?",
      replySaved: "✅ ধন্যবাদ! তোমার উত্তর সংরক্ষণ করা হয়েছে।",
      langSet: "✅ ভাষা সেট করা হয়েছে:",
      langNotFound: "❌ এই ভাষাটি পাওয়া যায়নি।",
      langReset: "🔄 ভাষা রিসেট করা হয়েছে (ডিফল্টে ফিরে গেছে)",
      invalidCmd: "❌ ভুল কমান্ড!",
      usage: "✅ ব্যবহার করো:\n- tod truth\n- tod dare\n- tod lang bn",
      errorTruth: "❌ সত্য প্রশ্ন আনতে সমস্যা হয়েছে।",
      errorDare: "❌ ডেয়ার আনতে সমস্যা হয়েছে।"
    }
  },

  onStart: async function ({ api, event }) {
    const commandParts = event.body.trim().split(/\s+/);
    const subCommand = commandParts[1];
    const langCommand = commandParts[2];
    const userID = event.senderID;
    const threadID = event.threadID;
    const messageID = event.messageID;

    if (subCommand === "truth") {
      await this.sendTruth(api, event, userID);
    } else if (subCommand === "dare") {
      await this.sendDare(api, event, userID);
    } else if (subCommand === "lang") {
      if (langCommand && langCommand !== "reset") {
        if (this.isValidLanguage(langCommand)) {
          this.saveUserLang(userID, langCommand);
          await api.sendMessage(`${this.langs[langCommand].langSet} ${langCommand.toUpperCase()}`, threadID, messageID);
        } else {
          await api.sendMessage(`${this.langs["en"].langNotFound} '${langCommand}'\n✅ Available: bn, de, es, fr, hi, tl`, threadID, messageID);
        }
      } else if (langCommand === "reset") {
        this.resetUserLang(userID);
        await api.sendMessage(this.langs["bn"].langReset, threadID, messageID);
      } else {
        await api.sendMessage(this.langs["bn"].invalidCmd + "\n" + this.langs["bn"].usage, threadID, messageID);
      }
    } else {
      await api.sendMessage(this.langs["bn"].invalidCmd + "\n" + this.langs["bn"].usage, threadID, messageID);
    }
  },

  onReply: async function ({ api, event, Reply }) {
    const { userID, lang, type } = Reply;
    const userAnswer = event.body;
    const threadID = event.threadID;
    const messageID = event.messageID;

    const userLang = lang || "bn";
    const texts = this.langs[userLang] || this.langs["en"];

    // এখানে তুমি ইউজারের উত্তর লগ করছো, চাইলে ডাটাবেজে সেভ করতে পারো
    console.log(`User (${userID}) answered to ${type}: ${userAnswer}`);

    await api.sendMessage(texts.replySaved, threadID, messageID);
  },

  isValidLanguage: function (lang) {
    const availableLanguages = ["bn", "de", "es", "fr", "hi", "tl"];
    return availableLanguages.includes(lang);
  },

  saveUserLang: function (userID, lang) {
    let userData = {};
    if (fs.existsSync(TOD_JSON_PATH)) {
      const data = fs.readFileSync(TOD_JSON_PATH, "utf8");
      userData = JSON.parse(data);
    }
    userData[userID] = lang;
    fs.writeFileSync(TOD_JSON_PATH, JSON.stringify(userData, null, 2));
  },

  getUserLang: function (userID) {
    if (fs.existsSync(TOD_JSON_PATH)) {
      const data = fs.readFileSync(TOD_JSON_PATH, "utf8");
      const userData = JSON.parse(data);
      return userData[userID];
    }
    return null;
  },

  resetUserLang: function (userID) {
    let userData = {};
    if (fs.existsSync(TOD_JSON_PATH)) {
      const data = fs.readFileSync(TOD_JSON_PATH, "utf8");
      userData = JSON.parse(data);
    }
    delete userData[userID];
    fs.writeFileSync(TOD_JSON_PATH, JSON.stringify(userData, null, 2));
  },

  sendTruth: async function (api, event, userID) {
    const lang = this.getUserLang(userID) || "bn";
    const texts = this.langs[lang] || this.langs["en"];

    let question = "";
    if (lang === "bn") {
      question = banglaTruths[Math.floor(Math.random() * banglaTruths.length)];
    } else {
      try {
        const res = await axios.get("https://api.truthordarebot.xyz/v1/truth");
        question = res.data.translations[lang] || res.data.question;
      } catch (err) {
        console.error(err);
        question = texts.errorTruth;
      }
    }

    await api.sendMessage(`🟢 Truth:\n${question}\n\n${texts.askReply}`, event.threadID, (err, info) => {
      global.GoatBot.onReply.set(info.messageID, {
        commandName: "tod",
        type: "truth",
        userID,
        lang
      });
    });
  },

  sendDare: async function (api, event, userID) {
    const lang = this.getUserLang(userID) || "bn";
    const texts = this.langs[lang] || this.langs["en"];

    let question = "";
    if (lang === "bn") {
      question = banglaDares[Math.floor(Math.random() * banglaDares.length)];
    } else {
      try {
        const res = await axios.get("https://api.truthordarebot.xyz/v1/dare");
        question = res.data.translations[lang] || res.data.question;
      } catch (err) {
        console.error(err);
        question = texts.errorDare;
      }
    }

    await api.sendMessage(`🔴 Dare:\n${question}\n\n${texts.askReply}`, event.threadID, (err, info) => {
      global.GoatBot.onReply.set(info.messageID, {
        commandName: "tod",
        type: "dare",
        userID,
        lang
      });
    });
  }
};