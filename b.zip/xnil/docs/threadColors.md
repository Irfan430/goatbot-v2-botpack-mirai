# threadColors

Get a dictionary of valid thread theme colors.

## Usage
```js
console.log(api.threadColors);
```

## Returns
- Object mapping color names to theme IDs.
