# stopListenMqtt

Stop the MQTT listener (advanced, for bots/services that need to cleanly disconnect).

## Usage
```js
api.stopListenMqtt();
```
